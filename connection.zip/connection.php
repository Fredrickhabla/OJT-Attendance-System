<?php 
	//SQL Connection
	$Local = 'localhost';
	$Username = "root";
	$Password = "";		
	$DBname = "ojtformv3";		
 	/*   
	$Local = 'fdb1034.awardspace.net';
	$Username = "4470838_ojt";
	$Password = "lrzpP}-j30ITx2wl";		
	$DBname = "4470838_ojt";	
*/
	$Connection = mysqli_connect($Local, $Username, $Password, $DBname);

?>
